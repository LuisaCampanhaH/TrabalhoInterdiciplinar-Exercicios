import java.util.Scanner;

public class SomaDoisNumeros {

    public static void main(String[] args) {

        // Cria um objeto Scanner para ler a entrada do usuário
        Scanner input = new Scanner(System.in);

        // Solicita e lê o primeiro número
        System.out.print("Digite o primeiro número: ");
        double numero1 = input.nextDouble();

        // Solicita e lê o segundo número
        System.out.print("Digite o segundo número: ");
        double numero2 = input.nextDouble();

        // Calcula a soma dos dois números
        double soma = numero1 + numero2;

        // Exibe o resultado da soma
        System.out.println("A soma de " + numero1 + " e " + numero2 + " é: " + soma);

        // Fecha o scanner para liberar os recursos
        input.close();
    }
}
